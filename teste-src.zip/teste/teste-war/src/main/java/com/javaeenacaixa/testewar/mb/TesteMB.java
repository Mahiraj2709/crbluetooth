package com.javaeenacaixa.testewar.mb;

import java.io.Serializable;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import com.javaeenacaixa.testeejb.sessionbean.TesteBeanLocal;

/**
 * Managed bean da pagina de testes
 * @author eliomarcolino
 *
 */
@ManagedBean
@ViewScoped
public class TesteMB implements Serializable{

	//Injecao de dependencia do EJB
	@EJB
	private TesteBeanLocal testeBean;
	
	//Propriedades para binding das paginas JSF
	private String entrada;
	private String resultado;
	
	//Action de solicitacao de processamento
	public void solicitarProcessamento(){
		resultado = testeBean.efetuarOperacaoDeNegocio(entrada);
	}

	public String getEntrada() {
		return entrada;
	}

	public void setEntrada(String entrada) {
		this.entrada = entrada;
	}

	public String getResultado() {
		return resultado;
	}

	public void setResultado(String resultado) {
		this.resultado = resultado;
	}
}
